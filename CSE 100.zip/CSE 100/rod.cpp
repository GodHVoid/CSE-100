#include <iostream>
using namespace std;

int rodfus(int *L,int *p,int n)
{
	int s[n];
	int r[n];
    int max = 0;
    int index = 0;
	for(int j = 1;j <=n; j++)
	{
        for(int i=2;i<n;i++)
		r[j-1] = L[j-1]^2 + L[j]^2;
        s[j-1] = r[j-1] 
        if(max < s[j-1])
        {
            max = s[j-1];
            index = j-1;
        }
	}

	return max;
}


int main(int argc,char **argv)
{
	int size = 0;
	cin>>size;
	int* L;
    int* prices;
	L = new int[size];
    prices = new int[size];
	for(int i = 0;i < size;i++)
	{
		cin>>L[i];
	}
	cout<<rodfus(L,prices,size)<<endl;
}